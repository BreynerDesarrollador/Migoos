<?php
/**
 * Created by PhpStorm.
 * User: windows 8.1
 * Date: 14/06/2018
 * Time: 4:03 PM
 */
?>
@extends('layouts.admin')
@section('content')
    <transition>
        <router-view></router-view>
    </transition>
@endsection
