<?php
/**
 * Created by PhpStorm.
 * User: windows 8.1
 * Date: 19/06/2018
 * Time: 3:38 PM
 */
?>
        <!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
    <title>Llamado de emergencia</title>
</head>
<body>
<p>Hola! Se ha reportado un nuevo caso de emergencia a las 32432432434.</p>
<p>Estos son los datos del usuario que ha realizado la denuncia:</p>
<ul>
    <li>Nombre: Esto es una prueba</li>
    <li>Teléfono: 5435435</li>
    <li>DNI: 5454545</li>
</ul>
<p>Y esta es la posición reportada:</p>
<ul>
    <li>Latitud: 4543545</li>
    <li>Longitud: 4545</li>

</ul>
</body>
</html>
