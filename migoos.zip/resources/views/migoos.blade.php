<?php
/**
 * Created by PhpStorm.
 * User: windows 8.1
 * Date: 12/06/2018
 * Time: 1:32 PM
 */
?>
@extends('layouts.app')
@section('content')
    <app></app>
@endsection