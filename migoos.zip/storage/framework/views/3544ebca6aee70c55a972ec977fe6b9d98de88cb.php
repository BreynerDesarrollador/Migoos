<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/principal.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css"
          integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt"
          crossorigin="anonymous">
    <script>
        window.ciudadgeneral = 'Cartagena, Bolivar, Colombia';
    </script>
</head>

<nav class="navbar navbar-expand-lg navbar-light bg-color  navbar-inverse">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse"
            aria-controls="navbarCollapse"
            aria-expanded="false" aria-label="Toggle navigation">
        <i class="fas fa-bars"></i>
    </button>
    <div>
        <a class="navbar-brand" href="#">
            <img class="brand" src="img/brand.png" alt=""> Migoos</a>
    </div>
    <div class="collapse navbar-collapse justify-content-end" id="navbarCollapse">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="#">Crear un Evento</a>
            </li>

            <?php if(auth()->guard()->guest()): ?>
                <li class="nav-item">
                    <a class="nav-link" id="ingresar" href="#" data-toggle="modal" data-target="#exampleModalCenter"> Iniciar </a>
                </li>
            <?php else: ?>
                <li class="nav-item dropdown">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                       data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                              style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
            <?php endif; ?>
        </ul>
    </div>
</nav>
<body>
<div id="app">


    <div class="row">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Modal -->
    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog"
         aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalCenterTitle">Iniciar Sesion</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <div class="card">
                        <div class="card-header">
                            <a href="<?php echo e(route('social.auth', 'facebook')); ?>" type="button" class="btn btn-primary btn-lg btn-block">
                                <i class=" fab fa-facebook"></i> &nbsp; Facebook
                            </a>
                            <a href="<?php echo e(route('social.auth', 'google')); ?>" type="button" class="btn btn-danger  btn-lg btn-block">
                                <i class="fab fa-google"></i> &nbsp; Google +
                            </a>
                        </div>
                        <div class="card-body">
                            <div class="orSeparator">
                                <h5 class="card-title">Ya tengo una cuenta</h5>
                            </div>
                            <form method="POST" action="<?php echo e(route('login')); ?>" class="form" role="form"
                                  autocomplete="off" id="formLogin" novalidate="" method="POST">
                                <?php echo csrf_field(); ?>

                                <div class="form-group row">
                                    <label for="email"
                                           class="col-sm-12 col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                                    <div class="col-md-8 col-sm-12">
                                        <input id="email" type="email"
                                               class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                                               name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                                        <?php if($errors->has('email')): ?>
                                            <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="password"
                                           class="col-md-4 col-sm-12 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                                    <div class="col-md-8 col-sm-12">
                                        <input id="password" type="password"
                                               class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>"
                                               name="password" required>

                                        <?php if($errors->has('password')): ?>
                                            <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <div class="col-md-6 offset-md-4">
                                        <div class="checkbox">
                                            <label>
                                                <input type="checkbox"
                                                       name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> <?php echo e(__('Remember Me')); ?>

                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group row mb-0">
                                    <div class="col-md-12">
                                        <button type="submit" class="btn btn-primary btn-sm btn-block">
                                            <?php echo e(__('Login')); ?>

                                        </button>

                                        <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                            <?php echo e(__('Forgot Your Password?')); ?>

                                        </a>
                                        <a class="btn btn-link" href="<?php echo e(route('register')); ?>">
                                            <?php echo e(__('Quiero registrarme')); ?>

                                        </a>
                                    </div>
                                </div>
                            </form>

                        </div>
                        <div class="card-footer">
                            <p class="text">
                                <strong>Disfrute de los beneficios de tener una cuenta.</strong>
                                ¡Reservas en línea, reservas, opciones personalizadas, herramientas de planificación
                                todo lo que necesita para planificar
                                su próxima aventura!
                            </p>
                        </div>
                    </div>
                </div>
            </div></div>

    </div>
    </div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
<script src="/js/manifest.js"></script>
<script src="/js/vendor.js"></script>
<script src="/js/app.js"></script>

<?php echo $__env->yieldContent('script'); ?>
<?php if($errors->any()): ?>
    <script>
        $(document).ready(function () {
            document.getElementById('ingresar').click();
        });
    </script>
<?php endif; ?>
</body>
</html>
