<?php
/**
 * Created by PhpStorm.
 * User: windows 8.1
 * Date: 04/07/2018
 * Time: 1:41 PM
 */
?>
<section class="footer">
    <div class="container-fluid ">
        <div id="footer" class="container">
            <div class="row">
                <div class=" col-sm-12 col-md-4 col-lg-4">
                    <h3>Migoos.com.co</h3>
                    <h5>Enlaces</h5>
                    <ul>
                        <li>
                            <a href="">Paute con nosotros</a>
                        </li>
                        <li>
                            <a href="">Registre su negocio o evento</a>
                        </li>
                        <li>
                            <a href="">Contáctanos</a>
                        </li>
                        <li>
                            <a href="">Sobre Migoos</a>
                        </li>
                        <li>
                            <a href="">Términos de uso</a>
                        </li>
                        <li>
                            <a href="">Politica de privacidad</a>
                        </li>
                    </ul>
                </div>
                <div class="  col-sm-12 col-md-4 col-lg-4">
                    <h4>Contactenos</h4>
                    <p> Colombia/Español: +57 317 606 2441
                        <br>De 08:00 AM a 05:00 PM
                        <br>PBX: 57 5 6424646 Ext. 109
                        <br>E-mail: donde@jetsemani.com
                    </p>
                    <ul class="">
                        <li>
                            <a href="" target="_blank">
                                <img src="">
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="col-sm-12 col-md-4 col-lg-4">

                    <h4>Conectate con Nosotros</h4>
                    <ul>

                        <li>
                            <a href="http://">
                                <i id="social" class=" fab fa-facebook"></i>
                                &nbsp;
                                <label for=""> Facebook</label>
                            </a>
                        </li>
                        <li>
                            <a href="http://">
                                <i id="social" class="fab fa-instagram"></i>
                                &nbsp;
                                <label for=""> Instagram</label>
                            </a>
                        </li>
                        <li>
                            <a href="http://">
                                <i id="social" class="fab fa-google"></i>
                                &nbsp;
                                <label for=""> Google + </label>
                            </a>
                        </li>
                        <li>
                            <a href="http://"></a>
                        </li>
                    </ul>


                </div>
            </div>
        </div>
    </div>
    </div>
    <hr class="col-lg-8 " style=" color: azure;">
    <div class="col-lg-12">
        <p class="copy">© <?php echo e(date('Y')); ?> Migoos</p>
    </div>
</section>
