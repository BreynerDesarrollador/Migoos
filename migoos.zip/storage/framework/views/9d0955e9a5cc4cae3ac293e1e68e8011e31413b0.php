<?php
/**
 * Created by PhpStorm.
 * User: windows 8.1
 * Date: 12/06/2018
 * Time: 1:32 PM
 */
?>

<?php $__env->startSection('content'); ?>
    <app></app>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>